import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../providers/user_provider.dart';
import '../services/session_manager.dart';
import '../widgets/custom_app_bar.dart';
import '../widgets/custom_button.dart';
import 'auth/new_login_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _isLoading = false;
  String _newPassword = '';
  String _confirmPassword = '';
  String selectedLanguage = "en"; // Add language selector state
  late SharedPreferences prefs; // Add SharedPreferences

  @override
  void initState() {
    super.initState();
    _initSharedPreferences(); // Initialize SharedPreferences
  }

  _initSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    selectedLanguage = prefs.getString("app_language") ?? "en";
    setState(() {}); // Update UI with loaded language
  }

  _changeAdminPassword() async {
    if (_newPassword.isEmpty || _confirmPassword.isEmpty) {
      Fluttertoast.showToast(
        msg: 'Please fill in all password fields',
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );
      return;
    }

    if (_newPassword != _confirmPassword) {
      Fluttertoast.showToast(
        msg: 'Passwords do not match',
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );
      return;
    }

    if (_newPassword.length < 6) {
      Fluttertoast.showToast(
        msg: 'Password must be at least 6 characters',
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    final userProvider = Provider.of<UserProvider>(context, listen: false);
    final currentUser = userProvider.currentUser;

    if (currentUser != null) {
      // Create updated user with new password
      final updatedUser = currentUser.copyWith(
        password: _newPassword,
      );

      // Update user in database
      final success = await userProvider.updateUser(updatedUser);

      setState(() {
        _isLoading = false;
      });

      if (success) {
        Fluttertoast.showToast(
          msg: 'Password changed successfully!',
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
        // Clear password fields
        setState(() {
          _newPassword = '';
          _confirmPassword = '';
        });
      } else {
        Fluttertoast.showToast(
          msg: 'Failed to change password. Please try again.',
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
      }
    }
  }

  Future<void> _resetAllData() async {
    bool? confirm = await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirm Reset', style: GoogleFonts.poppins()),
          content: Text(
            'Are you sure you want to reset all data? This action cannot be undone.',
            style: GoogleFonts.poppins(),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text('Cancel', style: GoogleFonts.poppins()),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text(
                'Reset',
                style: GoogleFonts.poppins(color: Colors.red),
              ),
            ),
          ],
        );
      },
    );

    if (confirm == true) {
      setState(() {
        _isLoading = true;
      });

      try {
        // With Supabase, we don't have a direct resetAllData method
        // In a real implementation, you would need to delete all records from all tables
        // For now, we'll just show a message that this functionality needs to be implemented
        
        Fluttertoast.showToast(
          msg: 'Data reset functionality needs to be implemented for Supabase',
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
        );

        // Logout user using new session management
        SessionManager sessionManager = SessionManager();
        final userProvider = Provider.of<UserProvider>(context, listen: false);
        
        // Remove current session
        if (userProvider.currentUser != null) {
          await sessionManager.removeSession(userProvider.currentUser!.id!);
        }
        
        // Clear current user in provider
        userProvider.signOut();

        // Navigate to login screen
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => const NewLoginScreen()),
          (route) => false,
        );
      } catch (e) {
        setState(() {
          _isLoading = false;
        });

        Fluttertoast.showToast(
          msg: 'Failed to reset data. Please try again.',
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final userProvider = Provider.of<UserProvider>(context);
    final currentUser = userProvider.currentUser;
    final isWorker = currentUser?.role == 'worker';
    final userRole = isWorker ? 'Worker' : 'Admin';
    
    return Scaffold(
      appBar: CustomAppBar(
        title: 'Settings',
        onLeadingPressed: () {
          Navigator.pop(context);
        },
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: const Text('Confirm Logout'),
                    content: const Text('Are you sure you want to logout?'),
                    actions: <Widget>[
                      TextButton(
                        child: const Text('Cancel'),
                        onPressed: () => Navigator.of(context).pop(false),
                      ),
                      TextButton(
                        child: const Text('Logout'),
                        onPressed: () => Navigator.of(context).pop(true),
                      ),
                    ],
                  );
                },
              );

              if (confirm == true) {
                await userProvider.signOut();
                if (context.mounted) {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => const NewLoginScreen()),
                    (route) => false,
                  );
                }
              }
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'System Settings',
              style: GoogleFonts.poppins(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: const Color(0xFF1E88E5), // Royal Blue
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Manage your app preferences',
              style: GoogleFonts.poppins(
                fontSize: 16,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 30),
            // Edit Admin Profile
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16), // Updated to consistent radius
              ),
              elevation: 3, // Updated elevation
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20), // Uniform padding
                leading: const Icon(
                  Icons.person, // Filled icon
                  color: Color(0xFF1E88E5), // Royal Blue
                ),
                title: Text(
                  'Edit Admin Profile',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text(
                  'Update your profile information',
                  style: GoogleFonts.poppins(),
                ),
                trailing: const Icon(Icons.arrow_forward_ios), // Filled icon
                onTap: () {
                  // Navigate to the enhanced admin profile screen
                  Navigator.pushNamed(context, '/admin_profile');
                },
              ),
            ),
            const SizedBox(height: 20),
            // Change Password Section (Dynamic based on user role)
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16), // Updated to consistent radius
              ),
              elevation: 3, // Updated elevation
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Change $userRole Password',
                      style: GoogleFonts.poppins(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 15),
                    TextField(
                      obscureText: true,
                      onChanged: (value) {
                        setState(() {
                          _newPassword = value;
                        });
                      },
                      decoration: InputDecoration(
                        labelText: 'New Password',
                        labelStyle: GoogleFonts.poppins(),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12), // Updated to consistent radius
                        ),
                        prefixIcon: const Icon(Icons.lock), // Filled icon
                      ),
                    ),
                    const SizedBox(height: 15),
                    TextField(
                      obscureText: true,
                      onChanged: (value) {
                        setState(() {
                          _confirmPassword = value;
                        });
                      },
                      decoration: InputDecoration(
                        labelText: 'Confirm Password',
                        labelStyle: GoogleFonts.poppins(),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12), // Updated to consistent radius
                        ),
                        prefixIcon: const Icon(Icons.lock), // Filled icon
                      ),
                    ),
                    const SizedBox(height: 20),
                    CustomButton(
                      text: 'Change Password',
                      onPressed: _changeAdminPassword,
                      isLoading: _isLoading,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            // Notification Settings
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16), // Updated to consistent radius
              ),
              elevation: 3, // Updated elevation
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20), // Uniform padding
                leading: const Icon(
                  Icons.notifications, // Filled icon
                  color: Color(0xFF1E88E5), // Royal Blue
                ),
                title: Text(
                  'Notification Settings',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text(
                  'Manage notification preferences',
                  style: GoogleFonts.poppins(),
                ),
                trailing: const Icon(Icons.arrow_forward_ios), // Filled icon
                onTap: () {
                  // Future implementation for notification settings
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Notification settings feature coming soon!'),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 20),
            // Select Theme
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16), // Updated to consistent radius
              ),
              elevation: 3, // Updated elevation
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20), // Uniform padding
                leading: const Icon(
                  Icons.brightness_4, // Filled icon
                  color: Color(0xFF1E88E5), // Royal Blue
                ),
                title: Text(
                  'Select Theme',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text(
                  'Light / Dark / System',
                  style: GoogleFonts.poppins(),
                ),
                trailing: const Icon(Icons.arrow_forward_ios), // Filled icon
                onTap: () {
                  // Future implementation for theme selection
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Theme selection feature coming soon!'),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 20),
            // 🌎 Language Section
            Text(
              "Language",
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12), // Updated to consistent radius
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: selectedLanguage,
                  items: const [
                    DropdownMenuItem(value: "en", child: Text("English")),
                    DropdownMenuItem(value: "hi", child: Text("Hindi")),
                    DropdownMenuItem(value: "gu", child: Text("Gujarati")),
                  ],
                  onChanged: (value) {
                    setState(() => selectedLanguage = value!);
                    prefs.setString("app_language", value!);
                  },
                ),
              ),
            ),
            const SizedBox(height: 20),
            // Reset All Data
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16), // Updated to consistent radius
              ),
              elevation: 3, // Updated elevation
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Reset All Data',
                      style: GoogleFonts.poppins(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'This will delete all records and reset the app to default settings.',
                      style: GoogleFonts.poppins(
                        color: Colors.grey[600],
                      ),
                    ),
                    const SizedBox(height: 20),
                    CustomButton(
                      text: 'Reset All Data',
                      onPressed: _resetAllData,
                      color: const Color(0xFFF44336), // Red
                      textColor: Colors.white,
                      isLoading: _isLoading,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}