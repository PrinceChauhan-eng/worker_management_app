import 'package:supabase_flutter/supabase_flutter.dart';

// Call Supabase.initialize(...) in main.dart before using this.
final supa = Supabase.instance.client;